from zapy import server
# (optional) setup authentication
# (optional) setup environment variables

if __name__ == "__main__":
    # only required when using GUI
    server.start_server({
        'reload': True
    })